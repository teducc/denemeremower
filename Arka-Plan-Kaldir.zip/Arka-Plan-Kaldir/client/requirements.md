## Packages
framer-motion | Page transitions and complex animations
react-dropzone | Drag and drop file uploads
clsx | Class name utility
tailwind-merge | Class name utility

## Notes
- Images are processed via POST /api/process-image which accepts FormData with 'image' field
- Response contains { originalUrl, processedUrl }
- URLs returned are relative or data URIs, ready to use in <img src="..." />
