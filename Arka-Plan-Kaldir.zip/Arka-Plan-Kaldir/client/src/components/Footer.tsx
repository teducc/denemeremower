import { Heart } from "lucide-react";

export function Footer() {
  return (
    <footer className="w-full py-8 mt-auto border-t border-border/40 bg-background/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="text-sm text-muted-foreground font-medium">
          &copy; {new Date().getFullYear()} BG Remover. Tüm hakları saklıdır.
        </div>
        
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <span>Türkiye'de</span>
          <Heart className="w-4 h-4 text-red-500 fill-red-500 animate-pulse" />
          <span>ile yapıldı</span>
        </div>
      </div>
    </footer>
  );
}
