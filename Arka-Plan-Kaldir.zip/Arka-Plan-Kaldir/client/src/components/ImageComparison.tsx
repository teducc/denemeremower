import { useState, useRef, useEffect } from "react";
import { MoveHorizontal, Download, RefreshCw } from "lucide-react";
import { motion } from "framer-motion";

interface ImageComparisonProps {
  original: string;
  processed: string;
  onReset: () => void;
}

export function ImageComparison({ original, processed, onReset }: ImageComparisonProps) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isResizing, setIsResizing] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = () => setIsResizing(true);
  const handleMouseUp = () => setIsResizing(false);

  const handleMouseMove = (e: React.MouseEvent | MouseEvent) => {
    if (!isResizing || !containerRef.current) return;
    
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    
    setSliderPosition(Math.min(Math.max(x, 0), 100));
  };

  useEffect(() => {
    if (isResizing) {
      window.addEventListener("mousemove", handleMouseMove as any);
      window.addEventListener("mouseup", handleMouseUp);
    }
    return () => {
      window.removeEventListener("mousemove", handleMouseMove as any);
      window.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isResizing]);

  const handleDownload = () => {
    const link = document.createElement("a");
    link.href = processed;
    link.download = "bg-removed.png";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-4">
        <h3 className="text-2xl font-bold font-display text-foreground">Sonuç Hazır! ✨</h3>
        <div className="flex items-center gap-3">
          <button
            onClick={onReset}
            className="flex items-center gap-2 px-4 py-2 rounded-xl font-medium text-muted-foreground hover:text-foreground hover:bg-secondary/50 transition-colors"
          >
            <RefreshCw className="w-4 h-4" />
            Yeni Resim
          </button>
          <button
            onClick={handleDownload}
            className="flex items-center gap-2 px-6 py-2.5 rounded-xl font-semibold bg-gradient-to-r from-primary to-indigo-600 text-white shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200"
          >
            <Download className="w-4 h-4" />
            İndir (PNG)
          </button>
        </div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative w-full aspect-[4/3] md:aspect-[16/9] rounded-2xl overflow-hidden shadow-2xl border border-border/50 bg-[url('https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=2070&auto=format&fit=crop')] bg-repeat bg-[length:20px_20px]"
        ref={containerRef}
      >
        {/* Background (Processed - Transparent) */}
        <img
          src={processed}
          alt="Processed"
          className="absolute inset-0 w-full h-full object-contain pointer-events-none"
        />

        {/* Foreground (Original) - Clipped */}
        <div
          className="absolute inset-0 overflow-hidden pointer-events-none"
          style={{ width: `${sliderPosition}%` }}
        >
          <img
            src={original}
            alt="Original"
            className="absolute top-0 left-0 max-w-none h-full w-full object-contain aspect-[inherit]"
            style={{ width: containerRef.current?.offsetWidth || '100%' }}
          />
        </div>

        {/* Slider Handle */}
        <div
          className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize z-10 shadow-[0_0_10px_rgba(0,0,0,0.5)]"
          style={{ left: `${sliderPosition}%` }}
          onMouseDown={handleMouseDown}
        >
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-lg flex items-center justify-center text-primary transform transition-transform hover:scale-110 active:scale-95">
            <MoveHorizontal className="w-5 h-5" />
          </div>
        </div>

        {/* Labels */}
        <div className="absolute bottom-4 left-4 px-3 py-1 bg-black/50 backdrop-blur-md rounded-full text-xs font-bold text-white pointer-events-none select-none">
          Orijinal
        </div>
        <div className="absolute bottom-4 right-4 px-3 py-1 bg-primary/80 backdrop-blur-md rounded-full text-xs font-bold text-white pointer-events-none select-none">
          Şeffaf
        </div>
      </motion.div>

      <p className="text-center text-sm text-muted-foreground">
        Karşılaştırmak için sürgüyü sağa ve sola sürükleyin.
      </p>
    </div>
  );
}
