import { useCallback } from "react";
import { useDropzone } from "react-dropzone";
import { Upload, ImageIcon, Loader2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

interface UploadZoneProps {
  onFileSelect: (file: File) => void;
  isProcessing: boolean;
}

export function UploadZone({ onFileSelect, isProcessing }: UploadZoneProps) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    if (acceptedFiles.length > 0) {
      onFileSelect(acceptedFiles[0]);
    }
  }, [onFileSelect]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/*': ['.png', '.jpg', '.jpeg', '.webp']
    },
    maxFiles: 1,
    disabled: isProcessing
  });

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div
        {...getRootProps()}
        className={cn(
          "relative group cursor-pointer overflow-hidden rounded-3xl border-3 border-dashed transition-all duration-300 ease-out p-10 md:p-16 text-center",
          isDragActive 
            ? "border-primary bg-primary/5 scale-[1.02]" 
            : "border-border hover:border-primary/50 hover:bg-secondary/30",
          isProcessing && "pointer-events-none opacity-80"
        )}
      >
        <input {...getInputProps()} />
        
        <AnimatePresence mode="wait">
          {isProcessing ? (
            <motion.div
              key="processing"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.8 }}
              className="flex flex-col items-center justify-center space-y-4"
            >
              <div className="relative">
                <div className="w-16 h-16 rounded-full border-4 border-primary/20 animate-[spin_3s_linear_infinite]" />
                <div className="absolute inset-0 w-16 h-16 rounded-full border-4 border-t-primary border-r-transparent border-b-transparent border-l-transparent animate-spin" />
                <SparkleIcon className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-primary" />
              </div>
              <div className="space-y-1">
                <h3 className="text-xl font-bold font-display text-foreground">İşleniyor...</h3>
                <p className="text-muted-foreground">Yapay zeka sihrini konuşturuyor ✨</p>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key="upload"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="flex flex-col items-center space-y-6"
            >
              <div className={cn(
                "w-20 h-20 rounded-2xl flex items-center justify-center transition-all duration-300",
                isDragActive ? "bg-primary text-white shadow-lg shadow-primary/30" : "bg-white dark:bg-white/10 text-muted-foreground group-hover:text-primary group-hover:scale-110 shadow-lg shadow-black/5"
              )}>
                {isDragActive ? (
                  <Upload className="w-10 h-10 animate-bounce" />
                ) : (
                  <ImageIcon className="w-10 h-10" />
                )}
              </div>
              
              <div className="space-y-2">
                <h3 className="text-2xl font-bold font-display text-foreground">
                  {isDragActive ? "Dosyayı buraya bırakın" : "Resim Yükle veya Sürükle"}
                </h3>
                <p className="text-muted-foreground max-w-sm mx-auto">
                  JPG, PNG veya WebP formatında herhangi bir resim. 
                  <br className="hidden sm:block"/>
                  Maksimum dosya boyutu 10MB.
                </p>
              </div>

              <button className="px-6 py-3 rounded-xl bg-foreground text-background font-semibold hover:bg-foreground/90 transition-colors shadow-lg">
                Dosya Seç
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

function SparkleIcon({ className }: { className?: string }) {
  return (
    <svg 
      viewBox="0 0 24 24" 
      fill="currentColor" 
      className={className}
      xmlns="http://www.w3.org/2000/svg"
    >
      <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
    </svg>
  );
}
