import { useMutation } from "@tanstack/react-query";
import { api, type ProcessImageResponse } from "@shared/routes";
import { useToast } from "@/hooks/use-toast";

export function useProcessImage() {
  const { toast } = useToast();

  return useMutation<ProcessImageResponse, Error, File>({
    mutationFn: async (file: File) => {
      const formData = new FormData();
      formData.append("image", file);

      const res = await fetch(api.images.process.path, {
        method: api.images.process.method,
        body: formData,
        // Note: Content-Type header is not set manually for FormData 
        // to allow browser to set boundary
      });

      if (!res.ok) {
        // Try to parse error message if available
        try {
          const errorData = await res.json();
          throw new Error(errorData.message || "İşlem başarısız oldu");
        } catch (e) {
          throw new Error("Resim işlenirken bir hata oluştu");
        }
      }

      const data = await res.json();
      return api.images.process.responses[200].parse(data);
    },
    onError: (error) => {
      toast({
        title: "Hata",
        description: error.message,
        variant: "destructive",
      });
    },
  });
}
