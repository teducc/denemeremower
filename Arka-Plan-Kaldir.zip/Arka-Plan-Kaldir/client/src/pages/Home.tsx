import { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { UploadZone } from "@/components/UploadZone";
import { ImageComparison } from "@/components/ImageComparison";
import { useProcessImage } from "@/hooks/use-image-process";
import { Check, Zap, Shield, Image as ImageIcon } from "lucide-react";
import { motion } from "framer-motion";

export default function Home() {
  const [result, setResult] = useState<{ original: string; processed: string } | null>(null);
  const { mutate: processImage, isPending } = useProcessImage();

  const handleFileSelect = (file: File) => {
    processImage(file, {
      onSuccess: (data) => {
        setResult({
          original: data.originalUrl,
          processed: data.processedUrl,
        });
      },
    });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background selection:bg-primary/20">
      <Header />

      <main className="flex-1 pt-24 pb-16">
        {/* Hero Section */}
        <section className="container mx-auto px-4 mb-20">
          {!result && (
            <div className="text-center max-w-3xl mx-auto mb-12 space-y-6">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
              >
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-primary/10 text-primary mb-6 border border-primary/20">
                  <span className="relative flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-primary"></span>
                  </span>
                  Yapay Zeka Destekli v2.0
                </span>
                
                <h1 className="text-5xl md:text-6xl lg:text-7xl font-display font-extrabold tracking-tight text-foreground leading-[1.1]">
                  Arka Planı <br />
                  <span className="gradient-text">Saniyeler İçinde</span> Kaldır
                </h1>
              </motion.div>

              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.1 }}
                className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto"
              >
                Gelişmiş yapay zeka teknolojisi ile fotoğraflarınızın arka planını 
                otomatik olarak temizleyin. %100 ücretsiz ve yüksek kalite.
              </motion.p>
            </div>
          )}

          {/* Interactive Area */}
          <motion.div
            layout
            className="w-full"
          >
            {result ? (
              <ImageComparison 
                original={result.original}
                processed={result.processed}
                onReset={() => setResult(null)}
              />
            ) : (
              <UploadZone 
                onFileSelect={handleFileSelect} 
                isProcessing={isPending} 
              />
            )}
          </motion.div>
        </section>

        {/* Features Grid (Only show when not viewing result for cleaner UI) */}
        {!result && (
          <section className="container mx-auto px-4 py-12 border-t border-border/40">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FeatureCard 
                icon={<Zap className="w-6 h-6 text-yellow-500" />}
                title="Şimşek Hızında"
                description="Saniyeler içinde sonuç alın. Beklemek yok, karmaşık ayarlar yok."
              />
              <FeatureCard 
                icon={<Shield className="w-6 h-6 text-green-500" />}
                title="Güvenli İşlem"
                description="Yüklediğiniz dosyalar işlem bittikten sonra otomatik olarak silinir."
              />
              <FeatureCard 
                icon={<ImageIcon className="w-6 h-6 text-blue-500" />}
                title="Yüksek Kalite"
                description="Detayları kaybetmeden profesyonel kalitede temizleme işlemi."
              />
            </div>
          </section>
        )}

        {/* Use Cases Section */}
        {!result && (
          <section className="py-20 bg-secondary/30">
            <div className="container mx-auto px-4">
              <div className="text-center mb-16">
                <h2 className="text-3xl font-bold font-display mb-4">Her İhtiyaç İçin Mükemmel</h2>
                <p className="text-muted-foreground max-w-2xl mx-auto">
                  E-ticaret ürünlerinden profil fotoğraflarına kadar her türlü görsel için optimize edilmiştir.
                </p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <UseCaseCard title="E-Ticaret" image="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=400&h=400&fit=crop" />
                <UseCaseCard title="Portreler" image="https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop" />
                <UseCaseCard title="Logolar" image="https://images.unsplash.com/photo-1626785774573-4b799314348d?w=400&h=400&fit=crop" />
                <UseCaseCard title="Arabalar" image="https://images.unsplash.com/photo-1494976388531-d1058494cdd8?w=400&h=400&fit=crop" />
              </div>
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="p-6 rounded-2xl bg-white dark:bg-card border border-border shadow-sm hover:shadow-md transition-shadow">
      <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center mb-4">
        {icon}
      </div>
      <h3 className="text-lg font-bold font-display mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
    </div>
  );
}

function UseCaseCard({ title, image }: { title: string; image: string }) {
  return (
    <div className="group relative aspect-square rounded-2xl overflow-hidden cursor-pointer">
      {/* Descriptive comment for Unsplash image */}
      {/* {title} example image for use case showcase */}
      <img src={image} alt={title} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end p-4">
        <span className="text-white font-bold font-display">{title}</span>
      </div>
    </div>
  );
}
