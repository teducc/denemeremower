import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import { removeBackground } from "@imgly/background-removal-node";

const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/process-image", upload.single("image"), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Resim yüklenmedi" });
      }

      console.log("Processing image...", req.file.originalname, req.file.size);

      // Process image using @imgly/background-removal-node
      // It accepts a Blob, File, or URL. We can pass the buffer directly?
      // The documentation says it accepts Blob or URL. 
      // We need to convert buffer to Blob. Node.js global Blob is available in newer versions.
      
      const blob = new Blob([req.file.buffer], { type: req.file.mimetype });
      const processedBlob = await removeBackground(blob);
      const buffer = Buffer.from(await processedBlob.arrayBuffer());
      const base64Image = `data:image/png;base64,${buffer.toString("base64")}`;
      const originalBase64 = `data:${req.file.mimetype};base64,${req.file.buffer.toString("base64")}`;

      // Optionally save to DB for history
      // await storage.createImage({
      //   originalUrl: "...",
      //   processedUrl: "..."
      // });

      res.json({ 
        originalUrl: originalBase64,
        processedUrl: base64Image 
      });
    } catch (error) {
      console.error("Background removal error:", error);
      res.status(500).json({ message: "İşlem sırasında bir hata oluştu." });
    }
  });

  return httpServer;
}
