import { z } from 'zod';
import { insertImageSchema, images } from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  images: {
    process: {
      method: 'POST' as const,
      path: '/api/process-image' as const,
      // Input is FormData, so we don't strictly validate body here, 
      // but we expect a 'image' file field.
      responses: {
        200: z.object({
          originalUrl: z.string(),
          processedUrl: z.string(),
        }),
        400: errorSchemas.validation,
        500: errorSchemas.internal,
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}

export type ProcessImageResponse = z.infer<typeof api.images.process.responses[200]>;
